// produtos.js com faixas incluídas
const produtos = [
  {
    id: 1, 
    nome: "A Great Chaos",
    descricao: "Ken Carson",
    preco: 207.90,
    imagem: "imagens/agc.png",
    faixas: [
    "Green Room",
      "Jennifer Body",
      "Fighting My Demons",
      "Singapore(feat. Destroy Lonely)",
      "Lose It",
      "Hardcore",
      "Me N My Kup",
      "It's Over",
      "Succubus",
      "Paranoid(feat. Destroy Lonely)",
      "Pots",
      "Like This(feat. Lil Uzi Vert, Destroy Lonely",
      "Overtime",
      "Vampire Hour",
      "Nightcore",
      "Nightcore 2",
      "Rockstar Lifestyle",
      "i need u",
      "loading",
      "more chaos",
      "toxic",
      "leather jacket",
      "mewtwo",
      "ss",
      "overseas"
    ]
  },
  {
    id: 2,
    nome: "Whole Lotta Red",
    descricao: "Playboi Carti",
    preco: 258.90,
    imagem: "imagens/wlr.png",
    faixas: [
      "Rockstar Made",
"Go2DaMoon (feat. Kanye West)",
"Stop Breathing",
"Beno!",
"JumpOutTheHouse",
"M3tamorphosis (feat. Kid Cudi)",
"Slay3r",
"No Sl33p",
"New Tank",
"Teen X (feat. Future)",
"Meh",
"Vamp Anthem",
"New N3on",
"Control",
"Punk Monk",
"On That Time",
"King Vamp",
"Place",
"Sky",
"Over",
"ILoveUIHateU",
"Die4Guy",
"Not PLaying",
"F33l Lik3 Dyin"
    ]
  },
  {
    id: 3,
    nome: "Die a Legend",
    descricao: "Polo G",
    preco: 157.90,
    imagem: "imagens/dal.png",
    faixas: [
      "Lost Files",
      "Battle Cry",
      "Through Da Storm",
      "Effortless",
      "Dyin’ Breed",
      "Deep Wounds",
      "Chosen 1",
      "Pop Out (feat. Lil Tjay)"
    ]
  },
  {
    id: 4,
    nome: "The Never Story",
    descricao: "JID",
    preco: 186.90,
    imagem: "imagens/tsne.jpg",
    faixas: [
      "Doo Wop",
      "General",
      "NEVER",
      "Hereditary",
      "EdEddnEddy",
      "8701",
      "All Bad",
      "Somebody"
    ]
  },
  {
    id: 5,
    nome: "Let's Start Here",
    descricao: "Lil Yachty",
    preco: 229.90,
    imagem: "imagens/lsh.png",
    faixas: [
      "the BLACK seminole.",
      "the ride-",
      "running out of time",
      "pRETTy",
      ":(failure):",
      "THE zone~",
      "WE SAW THE SUN!",
      "drive ME crazy!"
    ]
  },
  {
    id: 6,
    nome: "IGOR",
    descricao: "Tyler, the Creator",
    preco: 121.90,
    imagem: "imagens/igor.png",
    faixas: [
      "IGOR’S THEME (feat. Lil Uzi Vert)",
      "EARFQUAKE (feat. Playboi Carti",
      "I THINK",
      "RUNNING OUT OF TIME",
      "NEW MAGIC WAND",
      "A BOY IS A GUN*",
      "WHAT’S GOOD",
      "GONE, GONE / THANK YOU"
    ]
  },
  {
    id: 7,
    nome: "Pink Tape",
    descricao: "Lil Uzi Vert",
    preco: 215.90,
    imagem: "imagens/pnktp.webp",
    faixas: [
      "Flooded The Face",
      "Suicide Doors",
      "Aye (feat. Travis Scott)",
      "Crush Em",
      "Amped",
      "x2",
      "Died and Came Back",
      "Spin Again"
    ]
  },
  {
    id: 8,
    nome: "Meteora",
    descricao: "Linkin Park",
    preco: 179.90,
    imagem: "imagens/mtra.webp",
    faixas: [
      "Don’t Stay",
      "Somewhere I Belong",
      "Lying From You",
      "Hit the Floor",
      "Easier to Run",
      "Faint",
      "Figure.09",
      "Breaking the Habit"
    ]
  },
  {
    id: 9,
    nome: "Follow the Leader",
    descricao: "KORN",
    preco: 157.90,
    imagem: "imagens/ftl.png",
    faixas: [
      "It’s On!",
      "Freak on a Leash",
      "Got the Life",
      "Children of the Korn",
      "Dead Bodies Everywhere",
      "B.B.K.",
      "Pretty",
      "All in the Family"
    ]
  },
  {
    id: 10,
    nome: "Astroworld",
    descricao: "Travis Scott",
    preco: 157.90,
    imagem: "imagens/astwrld.png",
    faixas: [
      "STARGAZING",
      "CAROUSEL",
      "SICKO MODE",
      "STOP TRYING TO BE GOD",
      "NO BYSTANDERS",
      "SKELETONS",
      "YOSEMITE",
      "CAN'T SAY"
    ]
  },
  {
    id: 11,
    nome: "Toxicity",
    descricao: "System of a Down",
    preco: 156.90,
    imagem: "imagens/txcty.png",
    faixas: [
      "Prison Song",
      "Needles",
      "Deer Dance",
      "Jet Pilot",
      "X",
      "Chop Suey!",
      "Bounce",
      "Forest"
    ]
  },
  {
    id: 12,
    nome: "Die Lit",
    descricao: "Playboi Carti",
    preco: 206.90,
    imagem: "imagens/DL.webp",
    faixas: [
      "Long Time",
      "R.I.P.",
      "Lean 4 Real",
      "Old Money",
      "Shoota",
      "Mileage",
      "FlatBed Freestyle",
      "No Time"
    ]
  },
  {
    id: 13,
    nome: "MUSIC",
    descricao: "Playboi Carti",
    preco: 206.90,
    imagem: "imagens/MUSIC.png",
    faixas: [
      "H00DBYA",
      "CR3AM",
      "BACKR00MS",
      "UR TH3 1",
      "LOVEHRTS",
      "SK1ES",
      "IMMORTAL",
      "ROCKSTAR"
    ]
  },
  {
    id: 14,
    nome: "BABY BOI",
    descricao: "Playboi Carti",
    preco: 300,
    imagem: "imagens/BABYBOI.png",
    faixas: [
      "Drugs got me Numb",
      "Some More",
      "B5",
      "Problem Child",
      "Play This",
      "DOCTOR",
      "CHOPShOP",
    ]
  }
];
